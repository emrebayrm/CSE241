/* 
 * File:   directory.h
 * Author: emre
 *
 * Created on 21 Aralık 2015 Pazartesi, 14:11
 */

#ifndef DIRECTORY_H
#define	DIRECTORY_H

#include "HW8_Files.h"
#include <vector>

class directory :
	public Hw8_files_class::Files
{
public:
	directory(std::string _name, std::string _owner, int _size, std::string _day, bool visiblity = false);
	
	inline virtual std::string getName()const { return name; };
	inline virtual std::string getOwner()const { return owner; };
	inline virtual int getSizeofFile()const { return size; };


	directory & getParent() const;
	std::vector<Files*> getChild() const;

	Files & cd(Files & param);

	bool cp(Files & sources);

	void ls(char * Command = "") const;

	std::string Path()const;

	std::string properties()const;
	
	inline int get_Numbers_file()const { return child.size(); };

private:
	bool AddChild(Files& _file);
	bool SetParent(directory& _file);

	directory* parent;
	std::vector<Files*> child;
};



#endif	/* DIRECTORY_H */

