/* 
 * File:   TextFile.h
 * Author: emre
 *
 * Created on 21 Aralık 2015 Pazartesi, 14:13
 */

#ifndef TEXTFILE_H
#define	TEXTFILE_H
#include "HW8_Files.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>

class TextFile :
	public Hw8_files_class::Files
{
public:
	TextFile(std::string _name, std::string _owner, int _size, std::string _day, bool visiblity);

	inline virtual std::string getName()const { return name; };
	inline virtual std::string getOwner()const { return owner; };
	inline virtual int getSizeofFile()const { return size; };

	Files & cd(Files & param);
	bool cp(Files & sources);
	std::string properties() const;
	std::string Path()const;
	void ls(char * Command = "") const;

	inline void show(void) { std::cout << text; };
	inline void edit(std::string _text) { text.append(_text); };

private:
	std::string text;
};


#endif	/* TEXTFILE_H */

