/* 
 * File:   Executable.cpp
 * Author: emre
 * 
 * Created on 21 Aralık 2015 Pazartesi, 14:12
 */

#include "Executable.h"
#include <iostream>
#include "directory.h"

Executable::Executable(std::string _name, std::string _owner, int _size, std::string _day, bool visiblity = true)
{
	name = _name;
	owner = _owner;
	size = _size;
	visible = visiblity;
	day = (_day);
}

Hw8_files_class::Files & Executable::cd(Hw8_files_class::Files & param)
{
	Hw8_files_class::Files *ret = NULL;
	std::cerr << "You re Not A Directory !! \n" ;
	if (dynamic_cast<directory*>(&param))
	{
		ret = dynamic_cast<directory*>(&param);

		ret->cd(param);
	}
	return *ret;
}

bool Executable::cp(Files & sources)
{
	Hw8_files_class::Files *ret;
	if (dynamic_cast<directory*>(&sources))
	{
		ret = dynamic_cast<directory*>(&sources);
		return ret->cp(*this);
	}

	return false;
}

std::string Executable::properties() const
{
	return std::string("-rwx");
}

void Executable::ls(char * Command) const
{
	return;
}

std::string Executable::Path() const
{
	std::string _path;
	_path.append("/");
	_path.append(name);

	return _path;
}


