/* 
 * File:   TextFile.cpp
 * Author: emre
 * 
 * Created on 21 Aralık 2015 Pazartesi, 14:13
 */

#include "TextFile.h"
#include"HW8_Files.h"

TextFile::TextFile(std::string _name, std::string _owner, int _size, std::string _day, bool visiblity = true)
{
	name = _name;
	owner = _owner;
	size = _size;
	visible = visiblity;
	day = (_day);
}

Hw8_files_class::Files & TextFile::cd(Files & param)
{
	Hw8_files_class::Files *null = NULL;
	return *null;
}

bool TextFile::cp(Files & sources)
{
	return false;
}

std::string TextFile::properties() const
{
	return std::string("-rwx");
}

std::string TextFile::Path() const
{
	std::string _path;
	_path.append("/");
	_path.append(name);

	return _path;
}

void TextFile::ls(char * Command) const
{
	return;
}