/* 
 * File:   Executable.h
 * Author: emre
 *
 * Created on 21 Aralık 2015 Pazartesi, 14:12
 */

#ifndef EXECUTABLE_H
#define	EXECUTABLE_H

#include "HW8_Files.h"
#include<iostream>

class Executable :
	public Hw8_files_class::Files
{
public:
	Executable(std::string _name, std::string _owner, int _size, std::string _day, bool visiblity);

	inline virtual std::string getName()const { return name; };
	inline virtual std::string getOwner()const { return owner; };
	inline virtual int getSizeofFile()const { return size; };

	Files & cd(Files & param);
	bool cp(Files & sources);
	std::string properties() const;
	std::string Path()const;
	void ls(char * Command = "") const;

	void run(void) { std::cout << "I am Exe file "; };

};



#endif	/* EXECUTABLE_H */

