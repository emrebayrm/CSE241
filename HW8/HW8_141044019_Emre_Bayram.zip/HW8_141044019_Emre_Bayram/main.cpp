/* 
 * File:   main.cpp
 * Author: emre
 *
 * Created on 21 Aralık 2015 Pazartesi, 14:08
 */

#include <vector>
#include <iostream>
#include "directory.h"
#include "HW8_Files.h"
#include "Executable.h"
#include "TextFile.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

	/*Test Variables*/
	Hw8_files_class::Files *filedir;
	Executable myExec2("exe2", "emre", 125, "11/11/2145", false);
	directory mydir2("Mydir2", "sadf", 255, "25/54/2554",true);
	directory mydir("Mydir", "emmre", 125, "12/25/2015", true);
	Executable myExec("eexec.exe", "emre", 145, "12/25/2014",true);
	TextFile myText("text.txt", "Emre", 100, "12/25/2015", true);
	TextFile myText2("text2.txt", "Emre", 125, "12/25/2015", false);

	mydir2.cp(myExec);
	mydir.cp(mydir2);
	mydir2.cp(myExec2);
	mydir2.cp(myText);
	myText2.cp(mydir);

	/*After Copying operation files should be like that 
		mydir > mydir2			>
			  > myText2(hidden)	 myExec
								 myExec2(hidden)
								 myText
						 
														*/

	std::cout <<"\n" << mydir.getName() << " directory is showing  and ls shows with no Parameter\n";
	mydir.ls();
	
	std::cout <<"\n" << mydir.getName() <<  " directory is showing  and ls shows with l Parameter\n";
	mydir.ls("l");

	std::cout << "\n \n";
	std::cout <<"\n" << mydir.getName() << " Directory part showing with ls with lR parameter\n";
	mydir.ls("lR");

	std::cout << "\n \n";
	std::cout <<"\n" << mydir.getName() << " Directory part showing with ls with lRa parameter\n";
	mydir.ls("lRa");

	std::cout << "\n\n"<< mydir2.getName()<<" directory is showing  and ls shows with no Parameter\n";
	mydir2.ls();

	std::cout << "\n\n\n"<< mydir2.getName() <<"directory is showing  and ls shows with l Parameter\n";
	mydir2.ls("l");

	std::cout << "\n \n";
	std::cout <<"\n" << mydir2.getName()<< " Directory part showing with ls with lR parameter\n";
	mydir2.ls("lR");

	std::cout << "\n \n";
	std::cout <<"\n" << mydir2.getName()<< " Directory part showing with ls with lRa parameter\n";
	mydir2.ls("lRa");

    return 0;
}

