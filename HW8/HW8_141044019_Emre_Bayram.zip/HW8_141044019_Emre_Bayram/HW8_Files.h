/* 
 * File:   HW8_Files.h
 * Author: emre
 *
 * Created on 21 Aralık 2015 Pazartesi, 14:09
 */

#ifndef HW8_FILES_H
#define	HW8_FILES_H
#include<string>
#include <vector>

namespace Hw8_files_class {
	class Files
	{
	public:
		inline virtual std::string getName() const { return name; } ;
		inline virtual std::string getOwner()const { return owner; } ;
		inline virtual int getSizeofFile() const { return size; } ;
		virtual std::string getDay() const { return day; };

		virtual std::string Path()const = 0;
		virtual void ls(char* Command = "")const = 0;
		virtual Files& cd(Files & param) = 0;
		virtual bool cp(Files & sources) = 0;

		virtual std::string properties()const = 0;

		inline bool get_visiblty() { return visible; };

	protected:
		std::string name;
		std::string owner;
		int size;
		std::string day;

		bool visible;
	};
}

#endif	/* HW8_FILES_H */

