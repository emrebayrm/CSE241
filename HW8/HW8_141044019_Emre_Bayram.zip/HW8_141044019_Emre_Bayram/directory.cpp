/* 
 * File:   directory.cpp
 * Author: emre
 * 
 * Created on 21 Aralık 2015 Pazartesi, 14:11
 */

#include "directory.h"
#include <iostream>
#include <iomanip>
#include <string.h>

directory::directory(std::string _name, std::string _owner, int _size, std::string _day , bool visiblity)
{
	name = _name;
	owner = _owner;
	size = _size;
	visible = visiblity;
	day = (_day);
	
	parent = NULL;
}

bool directory::SetParent(directory & _file)
{
	if (this == &_file)
	{	
		std::cerr << "Error You can't Set yourself as your parent";
		return false;
	}
	parent = &(_file);

	return true;
}

Hw8_files_class::Files & directory::cd(Files & param)
{
	if (dynamic_cast<directory*>(&param) == this)
		return *parent;
	
	for (int i = 0; i < child.size(); ++i)
	{
		if (child[i] == &param)
			return *(child[i]);
	}

	Hw8_files_class::Files *null = NULL;

	return *null;
}

bool directory::AddChild(Files & _file)
{
	if (this == &(_file))
	{
		std::cerr << "Error !!! You cant add yourself as your child";
		return false;
	}
	
	child.push_back(&(_file));

	return true;
}

bool directory::cp(Files & sources)
{
	if (dynamic_cast<directory *>(&sources))
		dynamic_cast<directory *>(&sources)->SetParent(*this);

	return AddChild(sources);
}

void directory::ls(char * Command) const
{
	bool showall = false;
	bool listall = false;
        bool recursive = false;
	
        for (int i = 0; Command[i] != '\0'; ++i)
        {
            if(Command[i] == 'a')
                showall = true;
            if(Command[i] == 'R')
                recursive = true;
            if(Command[i] == 'l')
                listall = true;
        }
        
        
	if (!recursive)
		for (int i = 0; i < child.size(); ++i)
		{
			std::cout << std::setw(15);
			if(showall || child[i]->get_visiblty() == true)
                        {
                            std::cout << child[i]->getName();
			
                            if (listall)
                            {
                                    std::cout << std::setw(15) << child[i]->properties();
                                    std::cout << std::setw(15) << child[i]->getOwner();
                                    std::cout << std::setw(15) << child[i]->getSizeofFile();
                                    std::cout << std::setw(15) << child[i]->getDay();
                            }
                            std::cout << "\n";
                        }
			
		}
	else {
		for (int i = 0; i < child.size(); ++i)
		{
			
			std::cout << std::setw(15);
			if(showall || child[i]->get_visiblty() == true)
                        {
                            std::cout << child[i]->getName();
			
                            if (listall)
                            {
                                    std::cout << std::setw(15) << child[i]->properties();
                                    std::cout << std::setw(15) << child[i]->getOwner();
                                    std::cout << std::setw(15) << child[i]->getSizeofFile();
                                    std::cout << std::setw(15) << child[i]->getDay();
                            }
                            std::cout << "\n";
                        }
                        std::cout << Path() << "/";
			child[i]->ls(Command);
			std::setw(10);
		}
	}
}

std::string directory::Path() const
{
	std::string _path;
	directory *curr = parent;

	for (int i = 0; curr != NULL; ++i)
	{
		_path.append("/");
		_path.append(curr->getName());

		curr = curr->parent;
	}

	_path.append("/");
	_path.append(name);

	return _path;
}

directory & directory::getParent() const
{
	return *(parent);
}

std::vector<Hw8_files_class::Files*> directory::getChild() const
{
	return child;
}


std::string directory::properties()const {
	std::string str("-rw");
	
	return str;
}