/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw9_141044019_emre_bayram;

import java.util.Vector;


public class Hw9_141044019_Emre_Bayram {
    private Vector<Double> coefs;
    
    public Hw9_141044019_Emre_Bayram() {
        coefs = new Vector<Double>(1);
        coefs.add(0.0);
    }

    public Hw9_141044019_Emre_Bayram(double _coefs[]) {
        
        coefs = new Vector<Double>(_coefs.length);
        
        for(double num : _coefs)
            coefs.add(num);
    }
    
    public double[] GetAll()
    {
        double[] ret_val;
        ret_val = new double[coefs.size()];
        
        for(int i = 0 ; i < ret_val.length; ++i)
            ret_val[i] = coefs.get(i);
        
        return ret_val;
    }
    
    public double GetCoefficient(int which){
        if (which < 0  && coefs.size() < which )
            return -1.0;
        
        return coefs.get(which);
    }

    public void setAll(double new_coefs[])
    {
        int i = 0;
        coefs.clear();
        coefs.setSize(new_coefs.length);
        
        for(double num : new_coefs)
        {
            coefs.set(i, num);
            ++i;
        }
    
    }
    
    public void setCoefs(double coef , int where) {
        if (coefs.size() < where)
        {
            System.err.println("Error !!! out of range");
            return ;
        }
        
        coefs.set(where, coef);
    }
    
    
    
    public double Evaluate(int x){
        double result = 0.0;
        int i = 0;
        for(double co : coefs)
        {
            result += co * Math.pow(x,i);
            ++i;
        }
        
        return result;
    }
    //Multiplies 2 adds and returns a new polynomial class. This method is constant method
    public Hw9_141044019_Emre_Bayram add(double other[]){
        double[] res;
        int end;
        if(other.length > coefs.size())
        {
            // if other big
            res = new double[other.length];
            
            end = coefs.size();
            
            for(int i = 0; i < other.length; ++i)
                res[i] = other[i];
            
            for(int i = 0; i < end; ++i)
                res[i] += coefs.get(i);
            
        }
        else {
            // our poly is bigger
            res = new double[coefs.size()];
            end = other.length;
        
            for(int i = 0; i < coefs.size(); ++i)
                res[i] = coefs.get(i);
            
            for(int i = 0; i < end; ++i)
                res[i] += other[i];
        }
        
        Hw9_141044019_Emre_Bayram ret_val = new Hw9_141044019_Emre_Bayram(res);
        
        return ret_val;
    }
    
    //subs 2 poly and returns a new polynomial class. This method is constant method
    public Hw9_141044019_Emre_Bayram subs(double other[]){
        double[] res;
        int end;
        if(other.length > coefs.size())
        {
            // if other big
            res = new double[other.length];
            
            end = coefs.size();
            
            for(int i = 0; i < other.length; ++i)
                res[i] = other[i];
            
            for(int i = 0; i < end; ++i)
                res[i] -= coefs.get(i);
            
        }
        else {
            // our poly is bigger
            res = new double[coefs.size()];
            end = other.length;
        
            for(int i = 0; i < coefs.size(); ++i)
                res[i] = coefs.get(i);
            
            for(int i = 0; i < end; ++i)
                res[i] -= other[i];
        }
        
        Hw9_141044019_Emre_Bayram ret_val = new Hw9_141044019_Emre_Bayram(res);
        
        return ret_val;
        
    }
    
    //Multiplies 2 poly and returns a new polynomial class. This method is constant method
    public Hw9_141044019_Emre_Bayram multiplies(double other[]){
    double[] res;
        int end;
        if(other.length > coefs.size())
        {
            // if other big
            res = new double[other.length];
            
            end = coefs.size();
            
            for(int i = 0; i < other.length; ++i)
                res[i] = other[i];
            
            for(int i = 0; i < end; ++i)
                res[i] *= coefs.get(i);
            
        }
        else {
            // our poly is bigger
            res = new double[coefs.size()];
            end = other.length;
        
            for(int i = 0; i < coefs.size(); ++i)
                res[i] = coefs.get(i);
            
            for(int i = 0; i < end; ++i)
                res[i] *= other[i];
        }
        
        Hw9_141044019_Emre_Bayram ret_val = new Hw9_141044019_Emre_Bayram(res);
        
        return ret_val;
    
    }

    @Override
    public String toString() {
        String res = "P(x) = ";
        String a = "";
        for(int i = coefs.size()-1; i > 0; --i)
        {
 
            a = a + String.format("%.3f",coefs.get(i));
            
            a = a + "x^" + Integer.toString(i);
            
            a = a + " + ";
            
        }
        a = a + Double.toString(coefs.get(0));
        
        res = res + a;
        
        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("HW9 Start \n");
        
        double test[] = {1.1,2.2,5.5,4.4,9.6};
        double test2[] = {1.0,2.0,3.0,4.0};   
        
        Hw9_141044019_Emre_Bayram objtest = new Hw9_141044019_Emre_Bayram(test);
        Hw9_141044019_Emre_Bayram objtest2 = new Hw9_141044019_Emre_Bayram(test2);
        
        System.out.println("First Poly > ");
        System.out.println(objtest.toString());
        System.out.println("");
        System.out.println("Second Poly >");
        System.out.println(objtest2.toString());
        System.out.println("");
        System.out.println("Getter And Setter Tests First polies first elem changes to 1.0");
        objtest.setCoefs(1.0, 0);
        System.out.println(objtest.toString());
        
        System.out.println("");
        System.out.println("");
        System.out.println("Addition test (First + Second >>> ");
        System.out.println(objtest.add(test2));
        
        System.out.println("");
        System.out.println("Substraction Test (First - Second >>> ");
        System.out.println(objtest.subs(test2));
    
        System.out.println("");
        System.out.println("multiplication test (First * Second >>> ");
        System.out.println(objtest.multiplies(test2));
        
        System.out.println("");
        System.out.println("");
        System.out.println("first poly result > P(5) = " + objtest.Evaluate(5));
        System.out.println("Secand Poly result > p(0) = " + objtest.Evaluate(0));
       
        System.out.println("");
        System.out.println("Lastly setting to second to first");
        
        
        objtest.setAll(test2);
        System.out.println("");
        System.out.println("First Poly > ");
        System.out.println(objtest.toString());
        System.out.println("Second Poly >");
        System.out.println(objtest2.toString());
        
        System.out.println("");
        System.out.println("");
        System.out.println("Test Has Been Completed");
        
    }
    
}
