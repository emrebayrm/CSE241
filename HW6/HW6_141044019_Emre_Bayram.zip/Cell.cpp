#include "Cell.h"

using namespace Hw6_Reversi;
using namespace Hw6_Cell;

int Reversi::game_num = 0;
int Reversi::livecell = 0;

namespace {
	void show_rules()
	{
		cout << endl;
		cout << "\t\t\t GAME RULES " << endl;
		cout << "1. You can't play if you can't eat any stones." << endl;
		cout << "2. You can't play filled places. " << endl;
		cout << "3. You Can't exceed map." << endl;
		cout << "  Good  Luck ! \n";

	}

	int read_only_digit(const char* str)
	{
		int first_digit;
		int second_digit;

		if ((int)str[0] > 57 || (int)str[0] < 48)
			return -1;
		else if ((int)str[1] == '\0') {
			if ((int)str[0] <= 57 && (int)str[0] >= 48)
				return (int)str[0] - 48;
		}
		else if ((int)str[2] == '\0') {
			first_digit = (int)str[0] - 48;
			second_digit = (int)str[1] - 48;

			return first_digit * 10 + second_digit;
		}
	}
}

//width x height y
/*Default olarak 6X6 lık bir reversi oyunu initialize eder.*/
Reversi::Reversi() {
    game_num++;
    is_started = true;

    height = 6;
    width = 6;

	int x, y = 0;

	GameCells = new Cell[height * width+1];

	for (int i = 1; i <= height * width; ++i)
	{
		x = i%width;
		GameCells[i].set_cell(x,y);
		if (i%width == 1)
			++y;
		if (x == width / 2 && y == height / 2)
		{
			GameCells[i -1].set_situation(X);
			GameCells[i ].set_situation(O);
			GameCells[i + width -1].set_situation(O);
			GameCells[i + width].set_situation(X);
		}
	}
	livecell += 4;
}

//That creates as squared game with your size

Reversi::Reversi(int size) {

    if (size < 2) {
        cerr << "Error width or height can be only positive numbers";
        getc(stdin);
        _Exit(1);
    }
    width = size;
    height = size;
	
    game_num++;
    is_started = true;

	GameCells = new Cell[height * width + 1];

	int x, y = 0;
	for (int i = 1; i <= height * width; ++i)
	{
		x = i%width;
		GameCells[i].set_cell(x, y);
		if (i%width == 1)
			++y;
		if (x == width / 2 && y == height / 2)
		{
			GameCells[i].set_situation(X);
			GameCells[i + 1].set_situation(O);
			GameCells[i + width].set_situation(O);
			GameCells[i + width + 1].set_situation(X);
		}
	}
	livecell += 4;
}

Reversi::Reversi(int _height, int _width) {
    if (_height < 2 && _width < 2) {
        cerr << "Error width or height can be only positive numbers";

        getc(stdin);
        _Exit(1);
    }

    height = _height;
    width = _width;

    game_num++;
    is_started = true;

	GameCells = new Cell[height * width + 1];

	int x, y = 0;

	for (int i = 1; i <= height * width; ++i)
	{
		x = i%width;
		GameCells[i].set_cell(x, y);
		if (i%width == 1)
			++y;
		if (x == width / 2 && y == height / 2)
		{
			GameCells[i].set_situation(X);
			GameCells[i + 1].set_situation(O);
			GameCells[i + width].set_situation(O);
			GameCells[i + width + 1].set_situation(X);
		}
	}
	if (height == 1 || width == 1)
		livecell += 2;
	else
	livecell += 4;
}

Reversi::Reversi(const Reversi & copy)
{
    if(&copy != this)
    {
	height = copy.height;
	width = copy.width;
	is_started = true;

	if (height < 2 || width < 2)
		livecell += 2;
	else 
		livecell += 4;

	GameCells = new Cell[width * height + 1];

	for (int i = 0; i < width * height +1; i++)
	{
		GameCells[i] = copy.GameCells[i];
	}
    }
}

Reversi::~Reversi() {
    game_num--;

	int count = 0;
	for (int i = 0; i < get_height() * get_width() ; i++)
	{
		if (GameCells[i].get_situation() != emptyy)
			count++;
	}

	livecell -= count;

	delete [] GameCells;
}

Reversi & Reversi::operator=(const Reversi & other){
    
    if(&other != this )
    {
    Cell *temp = new Cell[other.get_height() * other.get_width() + 1];
    
    width = other.get_width();
    height = other.get_height();
    
    is_started = true;
    
    for (int i = 0; i < other.get_width() * other.get_height() +1 ; ++i)
        temp[i] = other.GameCells[i];
    
    delete [] GameCells;
    
    GameCells = temp;
    }
    return *this;
}

bool Reversi::play(Cell cordinates) {

    int cord_x = cordinates.get_x();
    int cord_y = cordinates.get_y();
    if (cord_x > get_height() || cord_x < 0 || cord_y < 0 || cord_y > get_width())
        return false;
    Cell founded_cords;
    bool flag = false;
    //plays with O
    //check the cords which is empty
    if (GameCells[twodto1d(cord_x,cord_y)].get_situation() == emptyy) {
        //go up
        if ((cord_x - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y)].get_situation() == X) {

            if (search_in_array(cordinates, -1, 0, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go down
        if ((cord_x + 1 < get_height()) && GameCells[twodto1d(cord_x + 1,cord_y)].get_situation() == X) {

            if (search_in_array(cordinates, 1, 0, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go left
        if ((cord_y - 1 >= 0) && GameCells[twodto1d(cord_x,cord_y - 1)].get_situation() == X) {

            if (search_in_array(cordinates, 0, -1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go right
        if ((cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x,cord_y + 1)].get_situation() == X) {

            if (search_in_array(cordinates, 0, 1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go left up
        if ((cord_x - 1 >= 0 && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y - 1)].get_situation() == X) {

            if (search_in_array(cordinates, -1, -1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go left down
        if ((cord_x + 1 < get_height() && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x + 1,cord_y - 1)].get_situation() == X) {

            if (search_in_array(cordinates, 1, -1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go right up
        if ((cord_x - 1 >= 0 && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x - 1,cord_y + 1)].get_situation() == X) {

            if (search_in_array(cordinates, -1, 1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
        // go right down
        if ((cord_x + 1 < get_height() && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x + 1,cord_y + 1)].get_situation() == X) {

            if (search_in_array(cordinates, 1, 1, founded_cords, O)) {
                flag = true;
                change_between_cords(cordinates, founded_cords, O);
            }
        }
    }

    if (flag) {
        //every legal move increase the live cell number
        ++livecell;
        GameCells[twodto1d(cordinates.get_x(),cordinates.get_y())].set_situation(O);
    }
    
    return flag;
}



void Reversi::playGame() {

    // The Game getting ready
    int width, height;
    situation_enum sit = emptyy;

    bool flag = true;
    char buffer[50] = " ";
    do {
        cout << "Enter width pls >> ";
        cin >> buffer;
        width = read_only_digit(buffer);

        if (width != -1 && width > 1)
            flag = false;
        cout << "Wrong width value";
    } while (flag);

    flag = true;
    do {
        cout << "Enter height pls >> ";
        cin >> buffer;
        height = read_only_digit(buffer);

        if (height != -1 && width > 1)
            flag = false;
        cout << "Wrong height value";
    } while (flag);

    this->width = width;
    this->height = height;


    //Table initializing  
	
	resize(width, height);

    // Time to play game

    cout << "If you wanna enter settings menu anytime write settings then press enter \n";
    cout << " OK, Now you are 'O' and comp. is 'X'. \n";
    Cell cord;

    while (isgameover()) {
        print_game();

        cout << "Now Play , Enter cordinates (first number than alphabetic values) "
                << "and use lowercase letters,  like '1aa'  >> ";
                cord = read_cord();
        if (cord.get_x() == -2)
            Settigs_menu();
        else if (play(cord))
            play();
        else cout << "You Cant play there ";
        print_score();
    }
    
    cout << "Game is over" << endl;
    
    print_game();
    
    print_score();
    
    cout << endl;

}

void Reversi::print_game() const {
    cout << endl << "  ";

    char k = 'a';
    char j = 'a';
    for (int i = 97; i < 97 + width; ++k, i++) {

        cout << j << k
                << " ";
        if (k =='z') {
            k = 'a';
            ++j;
        }
    }
    cout << endl;

    for (int i = 0; i < height; i++) {
        cout << i + 1;
        if (i + 1 < 10)
            cout << " ";

        for (int j = 0; j < width; j++) {
            if (GameCells[twodto1d(i,j)].get_situation() == X)
                cout << 'X';
            else if (GameCells[twodto1d(i,j)].get_situation() == O)
                cout << 'O';
            else cout << '.';
            cout << "  ";
        }
        cout << endl;
    }
}

int Reversi::print_score() const {
    int cout_x = 0;
    int cout_o = 0;
    for (int i = 0; i < get_height(); ++i)
        for (int j = 0; j < get_width(); ++j) {
            if (GameCells[twodto1d(i,j)].get_situation() == X)
                ++cout_x;
            else if (GameCells[twodto1d(i,j)].get_situation() == O)
                ++cout_o;
        }

    cout << "X is " << cout_x << ", O is " << cout_o << endl;

    if (cout_x > cout_o)
        return 1;
    else if (cout_x < cout_o)
        return -1;
    else return 0;

}


// True when can play False cant play
bool Reversi::isgameover() const {
    int cord_x;
    int cord_y;
    Cell founded_cords;
    bool flag = false;
    Cell cords;

    for (int i = 0; i < get_height(); ++i)
        for (int j = 0; j < get_width(); ++j) {
            cord_x = i;
            cord_y = j;
            cords.set_cell(cord_x, cord_y);

            if (GameCells[twodto1d(cord_x,cord_y)].get_situation() == emptyy) {
                //go up
                if ((cord_x - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y)].get_situation() == X)
                    if (search_in_array(cords, -1, 0, founded_cords, O))
                        flag = true;
                // go down
                if ((cord_x + 1 < get_height()) && GameCells[twodto1d(cord_x + 1,cord_y)].get_situation() == X)
                    if (search_in_array(cords, 1, 0, founded_cords, O))
                        flag = true;
                // go left
                if ((cord_y - 1 >= 0) && GameCells[twodto1d(cord_x,cord_y - 1)].get_situation() == X)
                    if (search_in_array(cords, 0, -1, founded_cords, O))
                        flag = true;
                // go right
                if ((cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x,cord_y + 1)].get_situation() == X)
                    if (search_in_array(cords, 0, 1, founded_cords, O))
                        flag = true;
                // go left up
                if ((cord_x - 1 >= 0 && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y - 1)].get_situation() == X)
                    if (search_in_array(cords, -1, -1, founded_cords, O))
                        flag = true;
                // go left down
                if ((cord_x + 1 < get_height() && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x + 1,cord_y - 1)].get_situation() == X)
                    if (search_in_array(cords, 1, -1, founded_cords, O))
                        flag = true;
                // go right up
                if ((cord_x - 1 >= 0 && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x - 1,cord_y + 1)].get_situation() == X)
                    if (search_in_array(cords, -1, 1, founded_cords, O))
                        flag = true;
                // go right down
                if ((cord_x + 1 < get_height() && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x + 1,cord_y + 1)].get_situation() == X) {
                    if (search_in_array(cords, 1, 1, founded_cords, O))
                        flag = true;
                }
            }

        }
    return flag;
}

void Reversi::resize(int width, int height)
{
    
    Reversi temp(width,height);
    
    *this = temp; 
    
}

bool Reversi::compare_games(Reversi & other) const {
    int counter1 = 0, counter2 = 0;
    for (int i = 0; i < get_height() * get_width(); i++) {
		if (GameCells[i].get_situation() == O)
            ++counter1;
    }

    // counting other game

    for (int i = 0; i < other.get_height() * other.get_width(); i++) {
            if (other.GameCells[i].get_situation() == O)
                ++counter2;
    }

    if (counter1 > counter2)
        return true;
    return false;
}

int Reversi::move_comp_helper(const Cell & cord) const {
    int cord_x = cord.get_x();
    int cord_y = cord.get_y();
    Cell founded_cords;
    bool flag = false;
    int numberofeat = 0;

    int simulated_eat = 0;

    //plays with X
    //check the cords which is empty
    if (GameCells[twodto1d(cord_x,cord_y)].get_situation() == emptyy) {
        //go up
        if ((cord_x - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y)].get_situation() == O) {
            if (search_in_array(cord, -1, 0, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);

            }
        }
        // go down
        if ((cord_x + 1 < get_height()) && GameCells[twodto1d(cord_x + 1,cord_y)].get_situation() == O) {
            if (search_in_array(cord, 1, 0, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go left
        if ((cord_y - 1 >= 0) && GameCells[twodto1d(cord_x,cord_y - 1)].get_situation() == O) {

            if (search_in_array(cord, 0, -1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go right
        if ((cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x,cord_y + 1)].get_situation() == O) {
            if (search_in_array(cord, 0, 1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go left up
        if ((cord_x - 1 >= 0 && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y - 1)].get_situation() == O) {
            if (search_in_array(cord, -1, -1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go left down
        if ((cord_x + 1 < get_height() && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x + 1,cord_y - 1)].get_situation() == O) {
            if (search_in_array(cord, 1, -1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go right up
        if ((cord_x - 1 >= 0 && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x - 1,cord_y + 1)].get_situation() == O) {

            if (search_in_array(cord, -1, 1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
        // go right down
        if ((cord_x + 1 < get_height() && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x + 1,cord_y + 1)].get_situation() == O) {

            if (search_in_array(cord, 1, 1, founded_cords, X)) {
                simulated_eat += number_of_dots_between_cords(cord, founded_cords);
            }
        }
    }

    return simulated_eat;
}

bool Reversi::move_comp() {
    cout << endl << "Computer is Played" << endl;
    bool flag = false;
    Cell cords(0, 0);
    vector <int> sim;
    vector <Cell> cordinate;
    int k = 0;
    for (int i = 0; i < get_height(); ++i)
        for (int j = 0; j < get_width(); ++j) {

            cords.set_cell(i, j);
            int eat = move_comp_helper(cords);
            if (eat > 0) {
                flag = true;
                cordinate.push_back(Cell(cords.get_x(), cords.get_y()));
                sim.push_back(eat);
            }
        }
    if (flag) {
        //every legal move increase the live cell number
        ++livecell;

        int index;
        int max = 0;
        for (int i = 0; i < sim.size(); ++i)
            if (sim[i] > max) {
                index = i;
                max = sim[i];
            }

        cords.set_cell(cordinate[index].get_x(), cordinate[index].get_y());
        int cord_x = cords.get_x();
        int cord_y = cords.get_y();
        Cell founded_cords(0, 0);

        if ((cord_x - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y)].get_situation() == O) {

            if (search_in_array(cords, -1, 0, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go down
        if ((cord_x + 1 < get_height()) && GameCells[twodto1d(cord_x + 1,cord_y)].get_situation() == O) {

            if (search_in_array(cords, 1, 0, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go left
        if ((cord_y - 1 >= 0) && GameCells[twodto1d(cord_x,cord_y - 1)].get_situation() == O) {

            if (search_in_array(cords, 0, -1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go right
        if ((cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x,cord_y + 1)].get_situation() == O) {

            if (search_in_array(cords, 0, 1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go left up
        if ((cord_x - 1 >= 0 && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x - 1,cord_y - 1)].get_situation() == O) {

            if (search_in_array(cords, -1, -1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go left down
        if ((cord_x + 1 < get_height() && cord_y - 1 >= 0) && GameCells[twodto1d(cord_x + 1,cord_y - 1)].get_situation() == O) {

            if (search_in_array(cords, 1, -1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go right up
        if ((cord_x - 1 >= 0 && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x - 1,cord_y + 1)].get_situation() == O) {

            if (search_in_array(cords, -1, 1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        // go right down
        if ((cord_x + 1 < get_height() && cord_y + 1 < get_width()) && GameCells[twodto1d(cord_x + 1,cord_y + 1)].get_situation() == O) {

            if (search_in_array(cords, 1, 1, founded_cords, X)) {
                change_between_cords(cords, founded_cords, X);
            }
        }
        GameCells[twodto1d(cords.get_x(),cords.get_y())].set_situation(X);
    }
    
    return flag;
}

void Reversi::Settigs_menu() {

    char* filename;
    bool flag = false;
    char buff[25];
    do {
        cout << "        Settings" << endl;
        cout << "1. Load game from file" << endl;
        cout << "2. Save current game" << endl;
        cout << "3. Exit" << endl;
        cout << "4. Cancel" << endl;

        int answer;
        cin >> answer;
        switch (answer) {
            case 1: cout << "Enter file name";
                cin >> buff;
                if(!go_on(buff))
                    cout << "There is no such a file";
                else flag = true;
                break;
            case 2: 
                filename = save_game();
                cout << "File saved named as "  << filename;
                flag = true;
                break;
            case 3:
                flag = true;
                exit(1);
                break; 
            case 4:
                flag = true;
                break;
            default:
                cout << "pls enter 1 or 2 or 3 or 4 nothing more " << endl;
        }

    } while (!flag);
}


// Until correct cordinate got

Cell Reversi::read_cord() const {

    bool exception = false;
    bool flag = true;
    char player[50];
    Cell cord;

    do {
        cin >> player;
        int i;

        if (strcmp(player, "settings") == 0) {
            exception = true;
            break;
        }
        for (i = 0; player[i] != '\0'; ++i);

        if (i == 3) {
            if ((player[0] >= 48 && player[0] <= 57) && (player[1] >= 'a' && player[1] <= 'z')
                    && (player[2] >= 'a' && player[2] <= 'z')) {
                cord.set_cell((int) player[0] - 49, (int) (player[1] - 'a') + (int) (player[2] - 'a'));
            } else flag = false;
        } else if (i == 4) {
            int first_digit;
            int second_digit;

            if ((player[0] >= 48 && player[0] <= 57) && (player[2] >= 'a' && player[2] <= 'z')
                    && (player[1] >= 48 && player[1] <= 57) && (player[3] >= 'a' && player[3] <= 'z')) {
                first_digit = (int) player[0] - 48;
                second_digit = (int) player[1] - 49;

                cord.set_cell(first_digit * 10 + second_digit, (int) (player[2] - 'a') + (int) (player[3] - 'a'));
            } else flag = false;
        } else flag = false;

		for (i = 0; player[i]; i++)
			player[i] = '\0';
		cin.clear();

    } while (!flag);

    if (exception)
        return Cell(-2, -2);

    return cord;
}

char* Reversi::save_game() const {
    time_t timef;
    bool flag = true;

    int tt = ((int) time(&timef));

    char *filename = new char[20];
    strcpy(filename, "Reversi_");
    for (int i = strlen(filename); flag; ++i) {
        int remain = tt % 10;
        filename[i] = (char)(remain+49);

        tt /= 10;
        if (tt == 0)
            flag = false;
    }
    cout << filename;
    strcat(filename, ".rev");

    ofstream file;
    file.open(filename, ios::binary);

    file << get_width() << " " << get_height() ;
    
    for(int i =0; i < get_width(); ++i)
    {    for(int j = 0; j < get_height();++j)
            file << GameCells[twodto1d(i,j)].get_situation() << " ";
        file << endl;
    }
    file.close();
    return filename;
}

// a new game will open named as filename parameter 

bool Reversi::go_on(const char * filename) {
    fstream file(filename, ios::in);
    if (file) {
        int read;
        file >> read;
        height = read;
        file >> read;
        width = read;
        file >> read;
        game_num = read;

   
		// Table init Yapılacakkk !!!!!

        file.close();

        return true;
    }
    return false;
}

bool Reversi::search_in_array(const Cell & startpoints, int go_x, int go_y, Cell & founded_cords, situation_enum search) const {

    bool flag = false;
    int x = startpoints.get_x(), y = startpoints.get_y();

    while (!flag) {
        if (go_x < 0)
            x -= 1;
        else if (go_x > 0)
            x += 1;
        if (go_y < 0)
            y -= 1;
        else if (go_y > 0)
            y += 1;

        if ((y < 0 || x < 0) || (get_height() < x || get_width() < y))
            break;


        if (GameCells[twodto1d(x,y)].get_situation() == search) {
            flag = true;
        } else if (GameCells[twodto1d(x,y)].get_situation() == emptyy)
            break;

    }
    if (flag) {
        founded_cords.set_cell(x, y);
    }
    return flag;
}

void Reversi::change_between_cords(Cell cords, Cell founded_cords, situation_enum toChange) {
    int diff_x = cords.get_x() - founded_cords.get_x();
    int diff_y = cords.get_y() - founded_cords.get_y();

    int x = cords.get_x(), y = cords.get_y();
    while (!(x == founded_cords.get_x() && y == founded_cords.get_y())) {
        GameCells[twodto1d(x,y)].set_situation(toChange);
        if (diff_x < 0)
            x += 1;
        else if (diff_x > 0)
            x -= 1;
        if (diff_y < 0)
            y += 1;
        else if (diff_y > 0)
            y -= 1;


    }

}

int Reversi::number_of_dots_between_cords(Cell cord1, Cell cord2) const {
    if (cord1.get_x() == cord2.get_x() || cord1.get_y() == cord2.get_y())
        return (abs(cord1.get_x() - cord2.get_x()) + abs(cord1.get_y() - cord2.get_y()));
    return abs(cord1.get_x() - cord2.get_x());
}

bool Cell::operator==(Cell other) const {
    if(get_x() == other.get_x() && get_y() == other.get_y())
        return true;
    return false;
}


bool Cell::operator!=(Cell other) const {
    return !( *this == other);
}

bool Cell::operator<(Cell other) const {
    if(get_y() < other.get_y())
        return true;
    else if(get_y() == get_y() && get_x() < other.get_x() )
        return true;
    else false;
}

bool Cell::operator>(Cell other) const {
    return !(*this < other);
}

bool Cell::operator<=(Cell other) const {
    if(get_y() <= other.get_y())
        return true;
    return false;
}

bool Cell::operator>=(Cell other) const {
    if(get_y() >= other.get_y())
        return true;
    return false;
}

const Cell& Reversi::operator[](char* index) {
    int len = strlen(index);
    
    int x = (index[0] - 'a')*10 + (index[1] - 'a');
    int y = index[2] - '0';
    
    if(len == 4)
        y += index[3] - '0';
    
    
    if(x > get_width() && y > get_height())
        return Cell(-1000,-1000);
    
    
    return GameCells[twodto1d(x,y)];
}

const Cell& Reversi::operator()(char* index) {

    return operator [](index);
}

Cell Cell::operator++(int) {

    set_cell(get_x()+1,get_y()+1);
    
    return *this;
}

Cell Cell::operator--(int) {

    set_cell(get_x()-1,get_y()-1);
    
    return *this;    
}

Cell Cell::operator++() {
    Cell temp(*this);
    
    set_cell(get_x()+1,get_y()+1);
    
    return temp;
}

Cell Cell::operator--() {
    Cell temp(*this);
    
    set_cell(get_x()-1,get_y()-1);
    
    return temp;
}

istream& Hw6_Cell::operator>>(istream& inp,Cell& obj) {
    
    int x,y;
    cout << "Enter x >> ";
    inp >> x;
    
    cout << "Enter y >>  ";
    inp >> y;
    
    obj.set_cell(x,y,O);
    
    return inp;
}


ostream& Hw6_Cell::operator<<(ostream& out, const Cell& obj) {
    out << "x = " << obj.get_x() << "  Y = " << obj.get_y();
    
    return out;
}

ostream& Hw6_Reversi::operator<<(ostream& out, const Reversi& obj)
{
    obj.print_game();
    
    return out;
}

Reversi Reversi::operator++(int) {

    play();
    
    return *this;
}

Reversi Reversi::operator++() {
    
    Reversi temp(*this);
    
    play();
    
    return temp;
}

void Reversi::finish_game() {
    
    cout << "The Game has been ended, all mess is cleaning";
}

int Reversi::twodto1d(int i, int j) const
{
	return get_width() * i + j;
}