/*
 * File:   Cell.h
 * Author: emre
 *
 * Created on 07 Kasım 2015 Cumartesi, 21:09
 */

#ifndef CELL_H
#define	CELL_H
#include <vector>
#include <cstring>
#include <iostream>
#include <fstream>
#include <time.h>   // used for creating a unique save file
#include <stdlib.h> // used for exit

using namespace std;

namespace Hw6_Cell {
	typedef enum {
		X, O, emptyy
	} situation_enum;

	class Cell {
	public:

		Cell(int x, int y) : _x(x), _y(y), situation(emptyy) {
		};

		Cell() {
			_x = 0;
			_y = 0;
			situation = emptyy;
		};

		inline void set_cell(int x, int y, situation_enum sit) {
			_x = x;
			_y = y;
			situation = sit;
		};

		inline void set_situation(situation_enum sit) {
			situation = sit;
		};

		inline void set_cell(int x, int y) {
			_x = x;
			_y = y;
		};

		inline situation_enum get_situation() const {
			return situation;
		};

		inline int get_x() const {
			return _x;
		};

		inline int get_y() const {
			return _y;
		};

		// ###### OPERATOR OVERLOADING SECTION ###### //

		// LOGIC OPERATORS
		bool operator < (Cell other) const;
		bool operator <=(Cell other) const;
		bool operator > (Cell other) const;
		bool operator >=(Cell other) const;
		bool operator ==(Cell other) const;
		bool operator !=(Cell other) const;

		// INCREMENT and DECREMENT OPERATORS
			//postfix
		Cell operator ++(int);
		Cell operator --(int);
		//prefix
		Cell operator ++();
		Cell operator --();

	private:
		situation_enum situation;
		int _x;
		int _y;

	};

        // Stream Insertion and extraction operators
	ostream& operator<<(ostream & out, const Cell& obj);
	istream& operator>>(istream & inp, Cell& obj);

}


namespace Hw6_Reversi {
	typedef enum {
		UP, DOWN, LEFT, RIGHT, LEFTUP, LEFTDOWN, RIGHTUP, RIGHTDOWN
	} directions_t;

	using namespace Hw6_Cell;
	class Reversi {
	public:
		Reversi();
		Reversi(int size);
		Reversi(int height, int width);
		Reversi(const Reversi &copy);

		~Reversi();

		inline int get_width() const {
			return width;
		};

		inline int get_height() const {
			return height;
		};

		inline int get_runnig_game_number() const {
			return game_num;
		};

		inline double get_size() const {
			return ((double)height + (width * 0.01));
		};

		inline bool isGameStarted() {
			return is_started;
		};
		char* save_game() const;
		bool go_on(const char* file_name);

		inline bool play() {
			return move_comp();
		};
		bool play(Cell cordinates);
		void playGame();
		void print_game() const;

		int print_score() const;
		bool isgameover() const;

		void resize(int width, int height);
		
		bool compare_games(Reversi & other) const;

		inline static int live_cells() {
			return livecell;
		}

		void Settigs_menu();

		Cell read_cord()const;

		// ###### OPERATOR OVERLOADING SECTION ###### //

		 // INCREMENT and DECREMENT OPERATORS
			//postfix
		Reversi operator ++(int);
		//prefix
		Reversi operator ++();

		// INDEX OPERATOR

		const Cell& operator[](char* index);
		// FUNCTION OPERATOR

		const Cell& operator()(char* index);

                // ASSIGNMENT OPERATOR
                
                Reversi & operator=(const Reversi & other);
                
	private:
		void finish_game();

		int twodto1d(int i, int j) const;
		int move_comp_helper(const Cell &cord) const;
		bool move_comp();

		bool search_in_array(const Cell& startpoints, int go_x, int go_y, Cell &founded_cords, situation_enum search) const;
		void change_between_cords(Cell cords, Cell founded_cords, situation_enum toChange);

		int number_of_dots_between_cords(const Cell cord1, Cell cord2) const;

		bool is_started; // for information
		int height; // board height
		int width; // board width
		static int game_num; // is number of games

		static int livecell; // is represents full cells

		Cell * GameCells;	
	};

        ostream& operator<<(ostream &out, const Reversi& obj);
}
#endif	/* CELL_H */