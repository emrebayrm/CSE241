/* 
 * File:   main.cpp
 * Author: emre
 *
 * Created on 02 Kasım 2015 Pazartesi, 23:19
 */

#include <iostream>
#include "Cell.h"

using namespace std;

using namespace Hw6_Reversi;

void CallByValue(Reversi value);
/*
 * 
 */
int main(int argc, char** argv) {
	
    cout << "Test Main has been statarted " << endl;
    
    // Test Assignment Operator
    {
    Reversi Deneme;
    
    Reversi Deneme2(5,9);
    
    Deneme.play();
    cout << "!!!!!   Assignment operator is Testing !!!!!";
    cout << "first object has been created" << endl;
    cout << Deneme;
    cout << " And Second" << endl;
    cout << Deneme2;
    
    Deneme = Deneme2;
    cout << "assignt second to first And Here is the fist" << endl;
    cout << Deneme;
    }
    cout << "\n\n\n\nTesting Copy Constructor\n";
    //copy Constructor testing 
    {
        Reversi deneme(7,9);
        
        Reversi deneme2(deneme);
        
        cout << "second reversi game created from the first obje "<< 
                endl<<
                "here is the code"<< endl
                <<"Reversi deneme(7,9); Reversi deneme2(deneme);"<< endl;
        cout << deneme << deneme2;
    }
    
    //call by value call by reference
    {
        Reversi Deneme;
        
        Reversi Deneme2;
        
        Deneme++;
        
        cout << "Class Has a Compare func and it is reference value";
        
        if(Deneme.compare_games(Deneme))
            cout <<"This Game is better";
        else cout << "Other Game is better";
        
        cout << "Call by value "<< endl;
        cout << "First View of Game " <<Deneme2; 
        CallByValue(Deneme2);
        
        cout << "After The Call By value " << Deneme2 << "As you Can See Nothing has been changed";
        
    }
    
    cout << endl << "End of Test";
        
	return 0;
}



void CallByValue(Reversi value)
{
    cout << "I m getting a reversi Game as Call By Value and playing one step" << endl;
    value++;
    cout << value;
}