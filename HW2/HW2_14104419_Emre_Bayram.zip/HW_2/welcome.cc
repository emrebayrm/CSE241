/*
 * File:   141044019_Emre_Bayram_HW2.cpp
 * Author: emre bayram
 *
 * Created on October 22, 2015, 2:22 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

class DayofYear
{
public:
    DayofYear(int d, int m): day(d), month(m) { };
    int day;
    int month;
};

class Person
{
public:
    Person(int w, int h): weight(w), height(h) { };
    int weight;
    int height;
};


// This function takes an array of any type and returns its index of most occured elements.
int return_mode (const void * base, size_t num, size_t size,
                 bool (* equals) (const void *, const void *));

// This function compares integer whether is equal.
bool compare_int(const void* el1,const void* el2);

// This function compares double whether is equal.
bool compare_double(const void* el1,const void* el2);

// This function compares char whether is equal.
bool compare_char(const void* el1,const void* el2);

// This function compares person class whether is equal.
bool compare_Person(const void* el1,const void* el2);

// This function compares dayofyear class whether is equal.
bool compare_DayofYear(const void* el1,const void* el2);

/*
 *
 */
int main(int argc, char** argv) {

    // TEST Section
    double arr_d[] = {1.3, 3.1, 7.1, 1.4, 3.1, 5.22, 7.1, 5.2, 7.1, 7.1};
    char arr_c[] = {'y', 'u', 's', 'u', 'f', 's', 'i', 'n', 'a', 'n'};
    int arr_i[] = {4, 3, 4, 4, 3, 5, 2, 9, 3, 1};
    DayofYear arr_day[] = {DayofYear(1,1),DayofYear(5,3),DayofYear(4,9),DayofYear(10,5),DayofYear(10,1),
                            DayofYear(3,1),DayofYear(11,3),DayofYear(6,8),DayofYear(10,3),DayofYear(1,1)};
    Person arr_person[] = {Person(90,150),Person(69,151),Person(60,150),Person(70,150),Person(69,180),
                            Person(70,150),Person(60,150),Person(66,155),Person(80,170),Person(69,160)};

    int size = 10;

    cout << "#########      TEST SECTION        ##########" << endl<< endl<< endl;
    int res =return_mode(arr_i, size, sizeof (int), compare_int);
    cout << "########## TESTING INTEGER " << endl;
    cout << "index > " << res << "and its value " << arr_i[res] << endl<< endl;

    res = return_mode(arr_d, size, sizeof (double), compare_double);
    cout << "########## TESTING DOUBLE " << endl;
    cout << "index > " << res << "and its value " << arr_d[res] << endl<< endl;

    res = return_mode(arr_c, size, sizeof (char), compare_char);
    cout << "########## TESTING CHAR " << endl;
    cout << "index > " << res << "and its value " << arr_c[res] << endl<< endl;

    res = return_mode(arr_day, size, sizeof (DayofYear), compare_DayofYear);
    cout << "########## TESTING DAYOFYEAR " << endl;
    cout << "index > " << res << "and its value " <<" Day = " << arr_day[res].day << "Month = " << arr_day[res].month<< endl << endl;

    res = return_mode(arr_person, size, sizeof (Person), compare_Person);
    cout << "########## TESTING PERSON " << endl;
    cout << "index > " << res << "and its value " << "Weight = " << arr_person[res].weight << " Height = " << arr_person[res].height<< endl << endl;

    // End Of Test Section
    return 0;
}


bool compare_double(const void* el1,const void* el2){


    double* p1 = (double*) el1;
    double* p2 = (double*) el2;

    if(*p1 == *p2)
        return true;
    else return false;
}

bool compare_int(const void* el1,const void* el2) {

    int* p1 = (int*) el1;
    int* p2 = (int*) el2;

    if(*p1 == *p2)
        return true;
    else return false;

}

bool compare_char(const void* el1,const void* el2)
{
    char* p1 = (char*) el1;
    char* p2 = (char*) el2;

    if(*p1 == *p2)
        return true;
    else return false;

}

bool compare_Person(const void* el1,const void* el2)
{
    Person* p1 = (Person*) el1;
    Person* p2 = (Person*) el2;

    if(p1->height == p2->height && p2->weight == p1->weight)
        return true;
    else return false;

}

bool compare_DayofYear(const void* el1,const void* el2)
{
    DayofYear* p1 = (DayofYear*) el1;
    DayofYear* p2 = (DayofYear*) el2;

    if(p1->day == p2->day && p1->month == p2->month)
        return true;
    else return false;

}

int return_mode (const void * base, size_t num, size_t size,
                 bool (* equals) (const void *, const void *))
{
    unsigned char *end =(unsigned char *) base + (num*size);

    int count2=0;
    int count=0;
    int index;
    int max=0;
    int search_index = 0;

    for(unsigned char *i =(unsigned char *) base; i < end; i = i + size)
    {
        for(unsigned char *j = i; j < end; j = j + size)
        {

            if(equals(i,j))
                {
                 ++count;
                }
        }

        if(count > count2)
        {
            if(count > max)
            {
                index = search_index;
                max = count;
            }
        }
        count = count2;

        ++search_index;
    }

    return index;
}
