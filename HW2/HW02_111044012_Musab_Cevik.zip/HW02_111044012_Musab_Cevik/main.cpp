//
//  HW02_111044012_Musab_Cevik
//
//  Created by Musab Cevik on 22.10.2015.
//  Copyright (c) 2015 Musab Cevik. All rights reserved.
//
//  Description:
//  The returned value should be array index of the mode element of the array.

/*##########################################################################*/
/*						libraries and Constant Macros						*/
/*##########################################################################*/

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <iomanip>

using namespace std;

#define SIZE		10
#define NAME_SIZE	50
#define ID_SIZE		12



/*##########################################################################*/
/*								CLASSES										*/
/*##########################################################################*/

class DayOfYear
{
public:
    int day, month, year;
};

class Person
{
public:
    char name[NAME_SIZE], surname[NAME_SIZE];
    char ID[ID_SIZE];
};



/*##########################################################################*/
/*							FUNCTIONS										*/
/*##########################################################################*/

///  Find Function  ///
int return_mode(const void* base, size_t num, size_t size, bool (*equals)
                (const void*, const void*));


///  Compare Functions  ///
/**
 pre:  elem ve max alir
 post: Eger elem ve max ayniysa return 1 yapar, degilse return 0
 **/
bool intComp   (const void *elem, const void *max);
bool charComp  (const void *elem, const void *max);
bool doubleComp(const void *elem, const void *max);
bool boolComp  (const void *elem, const void *max);
bool dayComp   (const void *elem, const void *max);
bool nameComp  (const void *elem, const void *max);



/*##########################################################################*/
/*								MAIN Function								*/
/*##########################################################################*/

int main(int argc, const char * argv[])
{
    int mode;
    
    /******    TESTING WITH INTEGERS    ******/
    int intArr[SIZE] = {0, 3, 2, 8, 4, 5, 9, 1, 7, 7};
    
    mode = (return_mode(intArr, SIZE, sizeof(int), intComp));
    
    cout << "-------------------------\n";
    cout << "TESTING WITH INTEGERS\n[ ";
    for (int i=0; i<SIZE; i++)
        cout << intArr[i] << " ";
    cout << "]"<< endl << "\n->Index of Mode> " << mode << endl;
    cout << "-------------------------\n\n\n";
    
    
    
    /******    TESTING WITH CHARS    ******/
    char charArr[SIZE] = {'x', 'w' , 'x', 'x', 'r', 'd', 'y', 'd', 'd', 'a'};
    
    mode = return_mode(charArr, SIZE, sizeof(char), charComp);
    
    cout << "-------------------------\n";
    cout << "TESTING WITH CHARS\n[ ";
    for (int i=0; i<SIZE; i++)
        cout << charArr[i] << " ";
    cout << "]"<< endl << "\n->Index of Mode> ";
    cout << mode << endl;
    cout << "-------------------------\n\n\n";
    
    
    /******    TESTING WITH DOUBLES    ******/
    double doubleArr[SIZE] = {2.5, 0.7, 0.9, 8.3, 0.1, 0.7, 2.4, 4.1, 4.1, 2.4};
    
    mode = return_mode(doubleArr, SIZE, sizeof(double), doubleComp);
    
    cout << "-------------------------\n";
    cout << "TESTING WITH DOUBLES\n[ ";
    for (int i=0; i<SIZE; i++)
        cout << doubleArr[i] << " ";
    cout << "]"<< endl << "\n->Index of Mode> ";
    cout << mode << endl;
    cout << "-------------------------\n\n\n";
    
    
    /******    TESTING WITH BOOLSS    ******/
    bool boolArr[SIZE] = {0};
    
    for (int i=0; i<SIZE; i++)
    {
        if (i%2==0)
            boolArr[i]=true;
        else
            boolArr[i] = false;
    }
    boolArr[2]= false;

    mode = return_mode(boolArr, SIZE, sizeof(bool), boolComp);
    
    cout << "-------------------------\n";
    cout << "TESTING WITH BOOLS\n[ ";
    for (int i=0; i<SIZE; i++)
        cout << boolArr[i] << " ";
    cout << "]"<< endl << "\n->Index of Mode> ";
    cout << mode << endl;
    cout << "-------------------------\n\n\n";
    
    
    /******    TESTING WITH struct DayOfYear    ******/
    DayOfYear DOY[SIZE];
    
    DOY[0].day = 14;
    DOY[0].month = 1;
    DOY[0].year = 1993;
    
    DOY[1].day = 9;
    DOY[1].month = 2;
    DOY[1].year = 1993;
    
    DOY[2].day = 9;
    DOY[2].month = 2;
    DOY[2].year = 1993;
    
    DOY[3].day = 11;
    DOY[3].month = 10;
    DOY[3].year = 1993;
    
    DOY[4].day = 14;
    DOY[4].month = 6;
    DOY[4].year = 1993;
    
    DOY[5].day = 9;
    DOY[5].month = 2;
    DOY[5].year = 1993;
    
    DOY[6].day = 21;
    DOY[6].month = 6;
    DOY[6].year = 1994;
    
    DOY[7].day = 14;
    DOY[7].month = 6;
    DOY[7].year = 1993;
    
    DOY[8].day = 8;
    DOY[8].month = 10;
    DOY[8].year = 1993;
    
    DOY[9].day = 9;
    DOY[9].month = 2;
    DOY[9].year = 1993;
    
    mode = return_mode(DOY, SIZE, sizeof(DayOfYear), dayComp);
    
    cout << "-------------------------\n";
    cout << "TESTING WITH DAYOFYEAR\n";
    cout << "Day:  [";
    for (int i=0; i<SIZE; i++)
        cout << setw(5) << left << DOY[i].day << " ";
    cout << "]"<< endl;
    
    cout << "Month:[";
    for (int i=0; i<SIZE; i++)
        cout << setw(5) << left << DOY[i].month << " ";
    cout << "]"<< endl;
    
    cout << "Year: [";
    for (int i=0; i<SIZE; i++)
        cout << setw(5) << left << DOY[i].year << " ";
    cout << "]"<< endl;
    cout << "\n->Index of Mode> ";
    cout << mode << endl;
    cout << "-------------------------\n\n\n";
    
    
    /******    TESTING WITH struct Person    ******/
    Person personOfInterest[SIZE];
    
    strcpy(personOfInterest[0].name, "harold");
    strcpy(personOfInterest[0].surname, "finch");
    strcpy(personOfInterest[0].ID, "92111");
    
    strcpy(personOfInterest[1].name, "harold");
    strcpy(personOfInterest[1].surname, "finch");
    strcpy(personOfInterest[1].ID, "92111");
    
    strcpy(personOfInterest[2].name, "joss");
    strcpy(personOfInterest[2].surname, "carter");
    strcpy(personOfInterest[2].ID, "56111");
    
    strcpy(personOfInterest[3].name, "john");
    strcpy(personOfInterest[3].surname, "reese");
    strcpy(personOfInterest[3].ID, "91111");
    
    strcpy(personOfInterest[4].name, "root");
    strcpy(personOfInterest[4].surname, "-");
    strcpy(personOfInterest[4].ID, "53111");
    
    strcpy(personOfInterest[5].name, "john");
    strcpy(personOfInterest[5].surname, "reese");
    strcpy(personOfInterest[5].ID, "91111");
    
    strcpy(personOfInterest[6].name, "john");
    strcpy(personOfInterest[6].surname, "reese");
    strcpy(personOfInterest[6].ID, "91111");
    
    strcpy(personOfInterest[7].name, "sameen");
    strcpy(personOfInterest[7].surname, "shaw");
    strcpy(personOfInterest[7].ID, "41111");
    
    strcpy(personOfInterest[8].name, "john");
    strcpy(personOfInterest[8].surname, "reese");
    strcpy(personOfInterest[8].ID, "91111");
    
    strcpy(personOfInterest[9].name, "root");
    strcpy(personOfInterest[9].surname, "-");
    strcpy(personOfInterest[9].ID, "53111");
    
    mode = return_mode(personOfInterest, SIZE, sizeof(Person), nameComp);
    
    cout << "-------------------------\n";
    cout << "TESTING WITH PERSON\n";
    cout << "Name:    [ ";
    for (int i=0; i<SIZE; i++)
        cout << setw(7) << left << personOfInterest[i].name << " ";
    cout << "]"<< endl;
    
    cout << "Surname: [ ";
    for (int i=0; i<SIZE; i++)
        cout << setw(7) << left << personOfInterest[i].surname << " ";
    cout << "]"<< endl;
    
    cout << "ID:      [ ";
    for (int i=0; i<SIZE; i++)
        cout << setw(7) << left << personOfInterest[i].ID << " ";
    cout << "]"<< endl;
    cout << "\n->Index of Mode> " << mode << endl;
    cout << "-------------------------\n\n\n";
    
    return 0;
}


/*##########################################################################*/
/*								FUNCTIONS									*/
/*##########################################################################*/

int return_mode(const void* base, size_t num, size_t size, bool (*equals)
                (const void*, const void*))
{
    int mode=0;
    int count = 0;
    
    const char *temp = static_cast<const char*>(base); 
    
    for(int i=0, k=0; k < num*size; i+=1, k+=size) //Tum elemanlara bakar
    {
        const char *value = &temp[k]; //Mevcut eleman bir degiskene atanir
        int tempCount = 1;

        for (int a=0; a < num*size; a+=size)
            if(equals((void *)&temp[a], (void *)value)) //Mevcut eleman digerleriyle karsilastirlir
                tempCount++; //Mevcut elemandan bulunduysa artirilir.
        
        if (tempCount > count) //Mevcut eleman sayisi bir onceki mevcut eleman sayisindan daha fazlaysa
        {
            mode = i; //indeksi kaydedilir ve
            count = tempCount; //En sik tekrarlanan eleman olarak guncellenir.
        }
    }
    return mode;
}



/**
 pre:  elem ve max alir
 post: Eger elem ve max ayniysa return 1 yapar, degilse return 0
 **/
bool intComp(const void *elem, const void *max)
{
    const int *num1 = static_cast<const int *>(elem);
    const int *num2 = static_cast<const int *>(max);
    
    if (*num1 == *num2)
        return true;
    else
        return false;
}



bool charComp(const void *elem, const void *max)
{
    const char *ch1 = static_cast<const char *>(elem);
    const char *ch2 = static_cast<const char *>(max);
    
    if (*ch1 == *ch2)
        return true;
    else
        return false;
}



bool doubleComp(const void *elem, const void *max)
{
    const double *doub1 = static_cast<const double *>(elem);
    const double *doub2 = static_cast<const double *>(max);
    
    if (*doub1 == *doub2)
        return true;
    else
        return false;
}



bool boolComp(const void *elem, const void *max)
{
    const bool *bool1 = static_cast<const bool *>(elem);
    const bool *bool2 = static_cast<const bool *>(max);
    
    if (*bool1 == *bool2)
        return true;
    else
        return false;
}



bool dayComp(const void *elem, const void *max)
{
    const DayOfYear *day1 = static_cast<const DayOfYear *>(elem);
    const DayOfYear *day2 = static_cast<const DayOfYear *>(max);
    
    if (day1->day == day2->day && day1->month == day2->month && day1->year == day2->year)
        return true;
    else
        return false;
}



bool nameComp  (const void *elem, const void *max)
{
    const Person *pers1 = static_cast<const Person *>(elem);
    const Person *pers2 = static_cast<const Person *>(max);
    
    if (strcmp(pers1->name, pers2->name) == 0 &&
        strcmp(pers1->surname, pers2->surname) == 0 &&
        strcmp(pers1->ID, pers2->ID) == 0)
        return true;
    else
        return false;
}


