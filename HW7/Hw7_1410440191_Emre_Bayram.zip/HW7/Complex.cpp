/* 
 * File:   Complex.cpp
 * Author: emre
 * 
 * Created on 17 Aralık 2015 Perşembe, 00:47
 */

#include "Complex.h"

using namespace Hw7_Complex;

Complex::Complex(Rational a): Rational(a) {
    imaginary;
}

Complex::Complex(Rational a, Rational b) : a(Rational(a)), b(Rational(b)){};

Hw7_Rational::Rational Complex::Get_imagianary_part() {
    return imaginary;
}

Hw7_Rational::Rational Complex::Get_real_part() {
    return GetValue();
}

void Complex::setValue(Rational a, Rational b) {
    Complex temp(a,b);
    
    *this = temp;
}



std::ostream& operator<<(std::ostream& os, const Complex& obj) {
    os << obj.Get_real_part() << " + " << obj.Get_imagianary_part() << "i";
    return os;
}
