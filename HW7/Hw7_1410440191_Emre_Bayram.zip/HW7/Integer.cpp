/* 
 * File:   Integer.cpp
 * Author: emre
 * 
 * Created on 16 Aralık 2015 Çarşamba, 20:14
 */

#include <stdlib.h>
#include "Integer.h"

using namespace Hw7_Integer;

Integer::Integer(): Hw7_NaturelNumber::NaturelNumber::NaturelNumber() {
    sign = true;
}

Integer::Integer(int _Value):Hw7_NaturelNumber::NaturelNumber(abs(_Value)) {
    if(_Value >= 0)
        sign = true;
    else sign = false;
}

int Integer::GetValue() const {
    if (!sign)
        return -Hw7_NaturelNumber::NaturelNumber::GetValue();
    return Hw7_NaturelNumber::NaturelNumber::GetValue();
}

void Integer::SetValue(int _Value) {
    Hw7_NaturelNumber::NaturelNumber::SetValue(abs(_Value));
    
    if(_Value >= 0)
        sign = true;
    else sign = false;
}

Integer& Integer::operator+(const Integer& right) const {
    Integer *temp = new Integer(GetValue() + right.GetValue());
    
    return (*temp);
}

Integer& Integer::operator-(const Integer& right) const {
    Integer *temp = new Integer(GetValue() - right.GetValue());
    
    return (*temp);
}

bool Integer::operator<(const Integer& right) const {
    return GetValue() < right.GetValue();
}

Integer& Integer::operator=(const Integer& right) {
    if (this == &right)
        return *this;
    
    SetValue(right.GetValue());
    
    return *this;
}
