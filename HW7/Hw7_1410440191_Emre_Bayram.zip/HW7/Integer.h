/* 
 * File:   Integer.h
 * Author: emre
 *
 * Created on 16 Aralık 2015 Çarşamba, 20:14
 */

#ifndef INTEGER_H
#define	INTEGER_H

#include "NaturelNumber.h"

namespace Hw7_Integer{
    class Integer : public Hw7_NaturelNumber::NaturelNumber {
    public:
        Integer();
        Integer(int _Value);
        int GetValue() const;

        void SetValue(int _Value);

        Integer& operator+(const Integer& right) const;
        Integer& operator-(const Integer& right) const;
        Integer& operator=(const Integer& right);
        
        bool operator<(const Integer& right) const;


        friend std::ostream& operator<<(std::ostream& os, const Integer& obj) {
            os << obj.GetValue();
            return os;
        }
        
    private:
        bool sign;
    };
}
#endif	/* INTEGER_H */

