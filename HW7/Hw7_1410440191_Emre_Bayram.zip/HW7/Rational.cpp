/* 
 * File:   Rational.cpp
 * Author: emre
 * 
 * Created on 16 Aralık 2015 Çarşamba, 21:49
 */

#include "Rational.h"
#include "Integer.h"
#include <cstring>
#include <stdlib.h>
#include <iostream>
#include <cmath>

using namespace Hw7_Rational;

Rational::Rational() : Hw7_Integer::Integer::Integer(){
    basmak = 0;
    exponent = 0;
}

Rational::Rational(const char* num) : Hw7_Integer::Integer::Integer(){
    basmak = 0;
    int sign = 1;
    int i = 0;
    char c = num[i];
    if (c == '-')
    {
        sign = -1;
        ++i;
    }
    
    char *temp = new char[strlen(num)];
    for(; c != '\0'; ++ i)
    {
        if(c == '.')
        {    
            strncpy(temp,num,i-1);
            Hw7_Integer::Integer::SetValue(atoi(temp));
            break;
        }
        c = num[i];
    }
    
    char *exponentpart = new char[strlen(num)];
    int j = 0;
    for (; num[i]; ++j, ++i)
    {
        basmak++; 
        exponentpart[j] = num[i];
    }
    exponent.SetValue(atoi(exponentpart));
    
    std::cout << exponent;
}

double Rational::GetValue() const {
    double number = Hw7_Integer::Integer::GetValue() + (exponent.GetValue() * pow10(-basmak));
    return number;
}

void Rational::SetValue(const char * _Value) {
    Rational temp(_Value);
    
    *this = temp;
}

Rational& Rational::operator+(const Rational& right) const {
    Rational *temp = new Rational;
    Hw7_Integer::Integer::operator +(right);
    temp->exponent = this->exponent + right.exponent;
    
    return *temp;
}

Rational& Rational::operator-(const Rational& right) const {
    Rational *temp = new Rational;
    
    temp->exponent= this->exponent - right.exponent;
    
    return (*temp);
}

bool Rational::operator<(const Rational& right) const {
    return GetValue() < right.GetValue();
}