/* 
 * File:   main.cpp
 * Author: emre
 *
 * Created on 16 Aralık 2015 Çarşamba, 20:00
 */
#include<iostream>
#include <cstdlib>
#include "Integer.h"
#include "Rational.h"
#include"NaturelNumber.h"
#include <cmath>
#include <cstring>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
        // Test Naturel Numbers
    {
        cout << "Testing Naturel Number class " << endl;
        Hw7_NaturelNumber::NaturelNumber example;
        Hw7_NaturelNumber::NaturelNumber example2(66);
        Hw7_NaturelNumber::NaturelNumber example3(example2);
        cout << example2 + example << endl;
        cout << example3 << endl ;
        example = example2 ;
        
        cout <<"Example = " << example <<"  Example2 = " << example2 <<"  Example = " << example3<< endl;
        
        if(example < example3)
            cout << "< operator works wrong" << endl;
        else cout << "< work normal" << endl ;
    }

    {
        cout << " Testing Integer class " << endl;
        Hw7_Integer::Integer example(8);
        Hw7_Integer::Integer example2(-6);
        Hw7_Integer::Integer example3(example2);
        
        cout << "Before \n " << "Example = " << example <<"  Example2 = " << example2 <<"  Example3 = " << example3<< endl;
        cout << example2 + example << endl;
        cout << example3 << endl ;
        example = example2 ;
        
        cout <<"After \n Example = " << example <<"  Example2 = " << example2 <<"  Example3 = " << example3<< endl;
        
        if(example < example3)
            cout << "< operator works wrong" << endl;
        else cout << "< work normal" << endl ;
    }
    
    {
        Hw7_Rational::Rational example("12.9");
        Hw7_Rational::Rational example2("14.1");
        
        cout << endl << example.GetValue();
    }
    
    
    return 0;
}

