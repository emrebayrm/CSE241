/* 
 * File:   Complex.h
 * Author: emre
 *
 * Created on 17 Aralık 2015 Perşembe, 00:47
 */

#ifndef COMPLEX_H
#define	COMPLEX_H
#include"Rational.h"
namespace Hw7_Complex 
{
    class Complex : public Hw7_Rational::Rational{
    public:
        Complex() : Hw7_Rational::Rational::Rational() {};
        Complex(Rational a);
        Complex(Rational a, Rational b);

        Hw7_Rational::Rational Get_real_part();
        Hw7_Rational::Rational Get_imagianary_part();

        void setValue(Rational a, Rational b);

        Complex& operator+(const Complex& right) const;
        Complex& operator-(const Complex& right) const;

        bool operator<(const Complex& right) const;

        friend std::ostream& operator<<(std::ostream& os, const Complex& obj);

    private:
        Hw7_Rational::Rational imaginary;
    };
}
#endif	/* COMPLEX_H */

