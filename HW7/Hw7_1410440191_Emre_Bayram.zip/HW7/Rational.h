/* 
 * File:   Rational.h
 * Author: emre
 *
 * Created on 16 Aralık 2015 Çarşamba, 21:49
 */

#ifndef RATIONAL_H
#define	RATIONAL_H

#include "Integer.h"

namespace Hw7_Rational{
    class Rational : public Hw7_Integer::Integer {
    public:
        Rational();
        Rational(int mantissa,Integer _exponent) : Integer(mantissa) , exponent(_exponent){};
        Rational(const char* num);
        
        double GetValue() const;

        void SetValue(const char* _Value);

        Rational& operator+(const Rational& right) const;
        Rational& operator-(const Rational& right) const;
        
        
        bool operator<(const Rational& right) const;


        friend std::ostream& operator<<(std::ostream& os, const Rational& obj)
        {
            os << obj.GetValue();
            return os;
        }
        
    private:
        Hw7_Integer::Integer exponent;
        int basmak;
    };
}
#endif	/* RATIONAL_H */

