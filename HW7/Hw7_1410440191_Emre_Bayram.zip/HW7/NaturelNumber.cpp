/* 
 * File:   NaturelNumber.cpp
 * Author: emre
 * 
 * Created on 16 Aralık 2015 Çarşamba, 20:02
 */

#include <iostream>

#include "NaturelNumber.h"

using namespace Hw7_NaturelNumber;

NaturelNumber::NaturelNumber(int _Value) {    
    if (_Value < 0)
    {    
        std::cerr << "Error !!! Naturel Numbers Cant be Negative number";
        Value = 0;
    }
    else
        Value = _Value;
}

void NaturelNumber::SetValue(int _Value) {
    if (_Value < 0)
    {    
        std::cerr << "Error !!! Naturel Numbers Cant be Negative number";
    }
    else 
        Value = _Value;
}


NaturelNumber& NaturelNumber::operator+(const NaturelNumber& right) const {
    NaturelNumber *temp = new NaturelNumber(GetValue() + right.GetValue());
    
    return *temp;
}

NaturelNumber NaturelNumber::operator-(const NaturelNumber& right) const {
    NaturelNumber *temp = new NaturelNumber(GetValue() - right.GetValue());
    
    return *temp;
}

NaturelNumber& NaturelNumber::operator=(const NaturelNumber& right) {
    if(this == &right)
        return *this;
    
    Value = right.GetValue();
    
    return *this;
}