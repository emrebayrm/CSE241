/* 
 * File:   NaturelNumber.h
 * Author: emre
 *
 * Created on 16 Aralık 2015 Çarşamba, 20:02
 */

#ifndef NATURELNUMBER_H
#define	NATURELNUMBER_H
#include <ostream>

namespace Hw7_NaturelNumber{
    class NaturelNumber {
    public:
        NaturelNumber() : Value(0){}
        NaturelNumber(int _Value);

        int GetValue() const {return Value;}

        void SetValue(int _Value);

        NaturelNumber& operator+(const NaturelNumber& right) const;
        NaturelNumber operator-(const NaturelNumber& right) const;
        NaturelNumber& operator=(const NaturelNumber& right);

        bool operator<(const NaturelNumber& right) const {
            return right.GetValue() > GetValue(); // Reuse greater than operator
        }


        friend std::ostream& operator<<(std::ostream& os, const NaturelNumber& obj) {
            os << obj.GetValue();
            return os;
        }
    private:
       unsigned int Value;
    };
}
#endif	/* NATURELNUMBER_H */