/* 
 * This class computes....
 * File:   Rational.h
 * Author: vislab
 *
 * Created on October 19, 2015, 2:09 PM
 */


#ifndef _RATIONAL_H__
#define _RATIONAL_H__

#include <iostream>

class Rational {
public:

    Rational(int nom, int denom);

    int get_nominator() const ;
    int get_denominator()const ;

    void set_nominator( int );
    void set_denominator( int );


    void toString() const;
    
    double real() const;
    
    int gcd() const;
    
    int gcd_wrapper( int a, int b ) const;
    
    void add( Rational other );
    
    const Rational operator+ ( const Rational &other ) const;
    
    static int get_counter() { return counter;}
    
    

private:

    static void set_counter( int p_counter ){  counter = p_counter;}
    
    
    
    int nominator;
    int denominator;

    static int counter;
    
};




#endif

