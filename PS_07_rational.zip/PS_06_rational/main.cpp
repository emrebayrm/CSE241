/* 
 * File:   main.cpp
 * Author: vislab
 *
 * Created on October 19, 2015, 2:08 PM
 */

#include "Rational.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     
    cout << Rational::get_counter() << endl;
    
    
    
    Rational r(4,6);

    cout << Rational::get_counter() << endl;
    
    
    Rational r2(2,4);
    
   
    
    r = (r + r2) ;
   
    
    
    r.toString();
    
    
    return 0;
}

