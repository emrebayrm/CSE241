/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044019_emre_bayram;
import java.util.*;
import java.lang.*;

class Syntax_error extends Exception{
    private String Message;

    public Syntax_error(String _Message) {
        Message = _Message;
    }

    public String getMessage() {
        return Message;
    }
}

class Expression extends Hw10_141044019_Emre_Bayram{
    private Vector<Expression> Exp; 
    
    Expression(){
      Exp = new Vector<Expression>();      
    }
    public void start_getting_exp() throws Syntax_error{
        
        Scanner input = new Scanner(System.in);
        String inp;
        String empty_str = "";
        int numb = 0;
        
        System.out.println("Enter your expression, after each operator or operand press enter, to end the expression press =");
        System.out.println("Enter your Expression element");
        
        inp = input.nextLine();
        
        while(inp.charAt(0) != '=')
        {
            if(inp.charAt(0) == '(' || inp.charAt(0) == ')')
            {
                if(inp.charAt(0) == '(')
                   Exp.add(new Paranthesis(true));
                else Exp.add(new Paranthesis(false));
            }
            else if(inp.charAt(0) >= '0' && inp.charAt(0) <= '9'){
                try{
                    numb = Integer.parseInt(inp);
                }catch(Exception e){
                    throw new Syntax_error("Number with  " + e.getMessage());
                }
                Exp.add(new Operand(numb));
            }
            else if(inp.charAt(0) == '*')
                Exp.add(new Operator('*'));
            else if(inp.charAt(0) == '/')
                Exp.add(new Operator('/'));
            else if(inp.charAt(0) == '+')
                Exp.add(new Operator('+'));            
            else if(inp.charAt(0) == '-')
                Exp.add(new Operator('-'));
            else {
                throw new Syntax_error("No operator or no operands has found");
            }
        
            System.out.println("Enter your Expression element");
            inp = empty_str;
            inp = input.next();   
            
            checkinput(inp);
        }
    }
    
    private void checkinput(String inp) throws Syntax_error
    {
        if(Exp.lastElement() instanceof Operator && search(inp,"*+-/"))
            throw new Syntax_error(inp + "cant put two operator");
        if(Exp.lastElement() instanceof Operand && search(inp,"123456789()"))
            throw new Syntax_error( " Error : Expression >> " + this.toString() +" input >>" + inp);
        if(Exp.lastElement() instanceof Paranthesis)
        {
            Paranthesis temp =  (Paranthesis)Exp.lastElement();
            
            if(temp.isOpenparanthesis() && search(inp,"-*/)"))
                throw new Syntax_error(" Error : Expression >> " + this.toString() +" input >>" + inp);
            else if (search(inp,"(123456789"))
                throw new Syntax_error(" Error : Expression >> " + this.toString() +" input >>" + inp);
        }

    }
    private boolean search(String s , String tosearch)
    {
        for (char ch : tosearch.toCharArray()) {
            for(char ch2 : s.toCharArray())
                if(ch2 == ch)
                    return true;
        }
        
        return false;
    }
    
    public int Calculate() throws ArithmeticException , Syntax_error
    {
        boolean flag = false;
        int indexofph = find_paranthesis(0);;
        
        while(indexofph != -1)
        {
            if(((Paranthesis)Exp.get(indexofph)).isOpenparanthesis())
            {
                do{
                    indexofph = find_paranthesis(indexofph+1);
                    if(indexofph == -1)
                        throw new Syntax_error("Couldn't Found closed Paranthesis");
                }while(!((Paranthesis)Exp.get(indexofph)).isOpenparanthesis()); 
            }
            else throw new Syntax_error("Paranthesis Error Can't Start With closed Paranthesis" + toString());

            indexofph = find_paranthesis(indexofph);
        }
        //Finished Succesfully No Paranthesis Error
        
        System.out.print("Calculate method henüz hazır değil");
        
        return -1;
    }
    
   
    private int find_paranthesis(int startp)
    {
        for (int i = startp; i < Exp.size(); ++i)
            if(Exp.elementAt(i) instanceof Paranthesis)
                return i;
        return -1;
    }
    
    public String toString(){
        String ret = "";
        for (int i = 0; i < Exp.size(); ++i)
        {
            ret += (Exp.elementAt(i)).toString();
        }
        return ret;
    }
    
}


class Operator extends Expression{
    private char op;

    public Operator(char _op){
        op = _op;
    }

    public char get_operator(){
        return op;
    }

    @Override
    public String toString() {
        return Character.toString(op);
    }
    
}

class Operand extends Expression{
    private int value;
    
    public Operand(int val){
        value = val;
    }

    public int get_value(){
        return value;
    }
    
    public void set_value(int val)
    {
        value = val;
    }
    
    public String toString()
    {
        return Integer.toString(value);
    }
    
}

class Paranthesis extends Expression{
    private boolean status; // for open 1 for close -1
    
    Paranthesis(boolean _status){
        status = _status;
    }
    
    boolean isOpenparanthesis(){
        return status;
    }

    @Override
    public String toString() {
        String ret;
        if(isOpenparanthesis())
            ret = "(";
        else ret =")";
        
        return ret;
    }
    
    
}


/**
 *
 * @author root
 */
public class Hw10_141044019_Emre_Bayram {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Expression exp = new Expression();
        try{
            exp.start_getting_exp();
            System.out.println(exp.toString());
        }catch(Syntax_error e)
        {
            System.out.println(e.getMessage());
        }
        
        
    }
    
}
