/* 
 * File:   main.cpp
 * Author: emre
 *
 * Created on 02 Kasım 2015 Pazartesi, 23:19
 */

#include <iostream>
#include <vector>
#include "Cell.h"
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
	
    cout << "Test Main has been statarted " << endl;
    
    
        Reversi deneme(10);
        
        deneme.playGame();
        
        Reversi deneme2 (15);
        
        cout << "Game is started " << endl;
        deneme2.play();
        deneme2.print_game();
        cout << "game is runnig " << endl;
        Reversi other = deneme2++;
        deneme2.print_game();
        cout << " Testing the undo movement with overloading --" << endl;
        --deneme2;
        deneme2.print_game();
        deneme2.print_score();
        
        if (other.compare_games(deneme2))
            cout << "Undo has been failed";
        else cout << "Undo has been accomplished";
        
        cout << endl << "End of Test";
        
	return 0;
}

