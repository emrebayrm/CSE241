/*
 * File:   Cell.h
 * Author: emre
 *
 * Created on 07 Kasım 2015 Cumartesi, 21:09
 */

#ifndef CELL_H
#define	CELL_H
#include <vector>
#include <cstring>
#include <iostream>
#include <fstream>
#include <time.h>   // used for creating a unique save file
#include <stdlib.h> // used for exit

typedef enum {
    X, O, emptyy
} situation_enum;

typedef enum {
    UP, DOWN, LEFT, RIGHT, LEFTUP, LEFTDOWN, RIGHTUP, RIGHTDOWN
} directions_t;

using namespace std;

class Cell {
public:

    Cell(int x, int y) : _x(x), _y(y), situation(emptyy) {
    };

    Cell() {
        _x = 0;
        _y = 0;
        situation = emptyy;
    };

    inline void set_cell(int x, int y, situation_enum sit) {
        _x = x;
        _y = y;
        situation = sit;
    };

    inline void set_situation(situation_enum sit) {
        situation = sit;
    };

    inline void set_cell(int x, int y) {
        _x = x;
        _y = y;
    };

    inline situation_enum get_situation() const {
        return situation;
    };

    inline int get_x() const {
        return _x;
    };

    inline int get_y() const {
        return _y;
    };

    // ###### OPERATOR OVERLOADING SECTION ###### //
    
    // Stream Insertion and extraction operators
    friend ostream& operator<<(ostream & out, const Cell& obj);
    friend istream& operator>>(istream & inp, Cell& obj);
    
    // LOGIC OPERATORS
    bool operator < (Cell other) const;
    bool operator <=(Cell other) const;
    bool operator > (Cell other) const;
    bool operator >=(Cell other) const;
    bool operator ==(Cell other) const;
    bool operator !=(Cell other) const;
    
    // INCREMENT and DECREMENT OPERATORS
        //postfix
    Cell operator ++(int );
    Cell operator --(int );
        //prefix
    Cell operator ++();
    Cell operator --();
    
private:
    situation_enum situation;
    int _x;
    int _y;

};

class Reversi {
public:
    Reversi();
    Reversi(int size);
    Reversi(int height, int width);

    ~Reversi();

    inline int get_width() const {
        return width;
    };

    inline int get_height() const {
        return height;
    };

    inline int get_runnig_game_number() const {
        return game_num;
    };

    inline double get_size() const {
        return ((double) height + (width * 0.01));
    };

    inline bool isGameStarted() {
        return is_started;
    };
    char* save_game() const;
    bool go_on(const char* file_name);

    inline bool play() {
        return move_comp();
    };
    bool play(Cell cordinates);
    void playGame();
    void print_game() const;

    int print_score() const;
    void show_rules() const;
    bool isgameover() const;

    bool compare_games(Reversi & other) const;

    inline static int live_cells() {
        return livecell;
    }

    void Settigs_menu();
    
    Cell read_cord()const;
    
    // ###### OPERATOR OVERLOADING SECTION ###### //

     // INCREMENT and DECREMENT OPERATORS
        //postfix
    Reversi operator ++(int );
    void operator --(int );
        //prefix
    Reversi operator ++();
    void operator --();
    
    // INDEX OPERATOR
    
    const Cell& operator[](char* index);
    // FUNCTION OPERATOR
    
    const Cell& operator()(char* index);
    
    // ADD ASSIGNMENT OPERATOR
    
    void operator+=(Cell cordinate);
    
    // Stream extraction
    
    friend ostream operator<<(ostream &inp, const Reversi obj);
    
    
private:
    void finish_game();

    int read_only_digit(const char* str) const;
    int move_comp_helper(const Cell &cord) const;
    bool move_comp();

    bool search_in_array(const Cell& startpoints, int go_x, int go_y, Cell &founded_cords, situation_enum search) const;
    void change_between_cords(Cell cords, Cell founded_cords, situation_enum toChange);

    int number_of_dots_between_cords(const Cell cord1, Cell cord2) const;

    bool is_started; // for information
    int height; // board height
    int width; // board width
    static int game_num; // is number of games

    static int livecell; // is represents full cells

    vector< vector<Cell> > gameCells;
    
    vector < vector < vector < Cell> > > gameTables; 
};


#endif	/* CELL_H */