/* 
 * File:   main.cpp
 * Author: vislab
 *
 * Created on October 19, 2015, 2:08 PM
 */

#include "Rational.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    Rational r(4,6);

    r.toString();
    
    
    cout << r.gcd() << endl;
    
    const Rational r_const(2,4);
    
    r_const.toString();
    
    cout << r_const.gcd() << endl;
    
    
        
    Rational r_3(1,0);
    
    r_3.toString();
    
    
    
    
    Rational r4(4,6);
    Rational r5(1,5);
    
    r4.add( r5 );
    
    r4.toString();

    
    
    
    
    return 0;
}

